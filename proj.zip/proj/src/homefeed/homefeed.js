import React, { useState } from "react";
import "./homefeed.css";
import PIN from "../pin/pin";
import HomeNavbar from "../mainnav/homenav";

export default function Homefeed() {
  return (
    <div>
      <HomeNavbar />
      <div className="Container">
        <PIN />
        <PIN />
        <PIN />
        <PIN />
        <PIN />
      </div>
    </div>
  );
}
