import './CreatePinMenu.css'

const CreatePinMenu = () => (
    <div>
        
    </div>
)
export default CreatePinMenu;
