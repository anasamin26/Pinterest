import "./CreatePin.css";
import CreatePinBlock from "../CreatePinBlock/CreatePinBlock";

const CreatePin = () => (
  <div style={{ backgroundColor: "#efefef" }}>
    <CreatePinBlock />
  </div>
);
export default CreatePin;
